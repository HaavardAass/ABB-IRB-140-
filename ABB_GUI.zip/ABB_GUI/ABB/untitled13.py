#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Nov 13 12:37:45 2023

@author: haavardaass
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Nov 11 01:09:35 2023

@author: haavardaass
"""
import numpy as np
import cv2
import tkinter as tk

LARGE_FONT = ("Verdana", 24)  # Doubling the font size

class IRB140ColorDetectionProgram(tk.Tk):
  
    def __init__(self, *args, **kwargs):
        tk.Tk.__init__(self, *args, **kwargs)
        self.title("IRB 140 Color Detection Program")
        container = tk.Frame(self)
        container.pack(side="top", fill="both", expand=True)
        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)
  
        self.frames = {}
  
        for F in (StartPage, Orange_robot, White_robot, Calibrate_colours, Pick_By_colour):
            frame = F(container, self)
            self.frames[F] = frame
            frame.grid(row=0, column=0, sticky="nsew")
  
        self.show_frame(StartPage)
  
    def show_frame(self, cont):
        frame = self.frames[cont]
        frame.tkraise()
          
class StartPage(tk.Frame):
  
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        image = tk.PhotoImage(file="/Users/haavardaass/Desktop/ABB/IRB140_color.png")
        background_label = tk.Label(self, image=image)
        background_label.image = image
        background_label.place(x=0, y=0, relwidth=1, relheight=1)
        
        # Create the button image for calibration
        button_image = tk.PhotoImage(file="/Users/haavardaass/Desktop/ABB/Button_orange_robot.png")
        button = tk.Button(self, image=button_image, command=lambda: controller.show_frame(Orange_robot))
        button.image = button_image
        button.place(x=20, y=670)  # Adjust the placement of the button within the frame
        
        # Create the button image for calibration
        button_image = tk.PhotoImage(file="/Users/haavardaass/Desktop/ABB/Button_White_robot.png")
        button_2 = tk.Button(self, image=button_image, command=lambda: controller.show_frame(White_robot))
        button_2.image = button_image
        button_2.place(x=1200, y=670)  # Adjust the placement of the button within the frame
        
        
        

class Orange_robot(tk.Frame):
  
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        
        # Create and place the background image
        background_image = tk.PhotoImage(file="/Users/haavardaass/Desktop/ABB/ABB_Orange.png")
        background_label = tk.Label(self, image=background_image)
        background_label.image = background_image
        background_label.place(x=0, y=0, relwidth=1, relheight=1)
        
        # Create the button image for calibration
        button_image = tk.PhotoImage(file="/Users/haavardaass/Desktop/ABB/Button_colour_calibration.png")
        button = tk.Button(self, image=button_image, command=lambda: controller.show_frame(Calibrate_colours))
        button.image = button_image
        button.place(x=60, y=80)  # Adjust the placement of the button within the frame
        
        # Create the button image for calibration
        button_image = tk.PhotoImage(file="/Users/haavardaass/Desktop/ABB/Button_pick_color.png")
        button = tk.Button(self, image=button_image, command=lambda: controller.show_frame(Pick_By_colour))
        button.image = button_image
        button.place(x=60, y=230)  # Adjust the placement of the button within the frame




class White_robot(tk.Frame):
  
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        
        # Set the image as the background on White_robot
        image = tk.PhotoImage(file="/Users/haavardaass/Desktop/ABB/ABB_white.png")
        background_label = tk.Label(self, image=image)
        background_label.image = image
        background_label.place(x=0, y=0, relwidth=1, relheight=1)
        
        # Create the button image for calibration
        button_image = tk.PhotoImage(file="/Users/haavardaass/Desktop/ABB/Button_colour_calibration.png")
        button_4 = tk.Button(self, image=button_image, command=lambda: controller.show_frame(Calibrate_colours))
        button_4.image = button_image
        button_4.place(x=20, y=20)  # Adjust the placement of the button within the frame

 
class Calibrate_colours(tk.Frame):
    
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        
        # Set the image as the background on White_robot
        image = tk.PhotoImage(file="/Users/haavardaass/Desktop/ABB/ABB.png")
        background_label = tk.Label(self, image=image)
        background_label.image = image
        background_label.place(x=0, y=0, relwidth=1, relheight=1)
        
        
    def nothing(x):
        pass

    # Create a black image, a window
    img = np.zeros((300,512,3), np.uint8)
    cv2.namedWindow('Color Detection')

    # Red trackbars
    cv2.createTrackbar("Red_L - H", "Color Detection", 136, 180, nothing)
    cv2.createTrackbar("Red_L - S", "Color Detection", 87, 255, nothing)
    cv2.createTrackbar("Red_L - V", "Color Detection", 111, 255, nothing)
    cv2.createTrackbar("Red_U - H", "Color Detection", 180, 180, nothing)
    cv2.createTrackbar("Red_U - S", "Color Detection", 255, 255, nothing)
    cv2.createTrackbar("Red_U - V", "Color Detection", 255, 255, nothing)
    
    webcam = cv2.VideoCapture(0)

    while True:
        _, imageFrame = webcam.read()
        hsvFrame = cv2.cvtColor(imageFrame, cv2.COLOR_BGR2HSV)
    
        # Red trackbars
        red_lower = np.array([cv2.getTrackbarPos("Red_L - H", "Color Detection"),
                              cv2.getTrackbarPos("Red_L - S", "Color Detection"),
                              cv2.getTrackbarPos("Red_L - V", "Color Detection")])
        red_upper = np.array([cv2.getTrackbarPos("Red_U - H", "Color Detection"),
                              cv2.getTrackbarPos("Red_U - S", "Color Detection"),
                              cv2.getTrackbarPos("Red_U - V", "Color Detection")])
    
        red_mask = cv2.inRange(hsvFrame, red_lower, red_upper)
        kernel = np.ones((5, 5), "uint8")
        red_mask = cv2.dilate(red_mask, kernel)
        res_red = cv2.bitwise_and(imageFrame, imageFrame, mask=red_mask)
    
        cv2.putText(imageFrame, 'Color Detection - Red', (10, 20), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 2)
        cv2.imshow("Color Detection", imageFrame)
        
        cv2.imshow("Red Detection", res_red)
    
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    
    cv2.destroyAllWindows()
        
        

class Pick_By_colour(tk.Frame):
    
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        
        # Set the image as the background on White_robot
        image = tk.PhotoImage(file="/Users/haavardaass/Desktop/ABB/ABB.png")
        background_label = tk.Label(self, image=image)
        background_label.image = image
        background_label.place(x=0, y=0, relwidth=1, relheight=1)        
    
          
app = IRB140ColorDetectionProgram()
app.geometry("1440x810")  # Setting window size to 1440x810
app.mainloop()